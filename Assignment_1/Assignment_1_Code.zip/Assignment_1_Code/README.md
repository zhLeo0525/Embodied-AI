# Assignment 1 — Code and Reproduction

This archive contains every notebook, analysis script, result file, and model
used in `Assignment_1_Report.pdf`.  It is self-contained except for the Python
packages and Drake's model cache described below.

## Layout

```
Assignment_1_Code/
├── Ch-3/                      Underactuated Robotics, Chapter 3
│   ├── Ch.3-examples/         Examples 3.1, 3.2, 3.5, 3.6 (notebooks + analysis)
│   └── Ch.3 Exercises/        Section 3.8: cartpole_balancing, cartpoles_urdf
├── Ch-4/                      Underactuated Robotics, Chapter 4
│   ├── Exp4'3 ... Exp4'6      Examples 4.3, 4.4, 4.5–4.6, Section 4.6
│   └── exp4_analysis/         analysis scripts + results_*.json
├── Ch-5/                      Underactuated Robotics, Chapter 5
│   ├── Ch.5-examples/         Examples 5.1, 5.2, Section 5.8 (MIQP, GCS)
│   └── exp5_analysis/         analysis scripts + results_*.json + gait .npz
├── Ch-1/                      Robotic Manipulation, Chapter 1
│   ├── examples/              Example 1.2 (teleoperation, both 2D and 3D)
│   ├── exercises/             Section 1.7, Exercises 1.1–1.4
│   ├── models/                local IIWA/WSG fallback models
│   └── exp1_analysis/         figure-generation script
└── requirements.txt
```

## Environment

Python 3.12 with the packages in `requirements.txt`:

```
drake==1.58.0
underactuated==2026.9.8
manipulation==2026.10.17
numpy==2.5.4
scipy==1.18.1
matplotlib==3.11.2
nbconvert
```

The notebooks were executed headlessly with

```bash
COLAB_TESTING=1 jupyter nbconvert --to notebook --execute --inplace \
  --ExecutePreprocessor.timeout=300 <notebook>.ipynb
```

`COLAB_TESTING=1` is required: it stops the MeshCat visualizer from waiting for
a browser connection.  Without it the notebook blocks.

## Running the analysis scripts

Each analysis script writes its figures next to itself and prints or writes the
numbers quoted in the report.  For example:

```bash
python Ch-3/Ch.3-examples/exp1_analysis/exp1_analysis.py
python Ch-4/exp4_analysis/one_d_hopper_analysis.py
python Ch-5/exp5_analysis/footstep_analysis.py
```

The saved `results_*.json` files are the outputs used in the report, so the
numbers can be checked without re-running the longer simulations.

## Drake model cache (`drake_models`)

Chapter 1 uses `package://drake_models/...` for the IIWA14, the WSG gripper and
the YCB mustard bottle.  If those packages are not already in Drake's package
map cache, Drake downloads them on first use.  If the download fails, place the
pinned `drake_models` archive in the local cache; the checksum of the official
archive must be preserved, otherwise the IIWA inertia/damping differ and the
Exercise 1.3 verification will not match.

The files in `Ch-1/models/` are a local fallback with stripped inertias; they
are enough to run the scenes but they do **not** reproduce the official
`q_final` in Exercise 1.3.  Use the official `drake_models` package for that
verification.

## Verified results

| Notebook / exercise | Autograder |
|---|---|
| `Ch-3/Ch.3 Exercises/cartpole_balancing.ipynb` | 13/13 |
| `Ch-3/Ch.3 Exercises/cartpoles_urdf.ipynb` | 12/12 |
| `Ch-4/Exp4'6-one_d_hopper.ipynb` | 13/13 |
| `Ch-5/Ch.5-examples/Exp5'8-footstep-planning.ipynb` (MIQP) | 16/16 |
| `Ch-5/Ch.5-examples/Exp5'8-footstep-planning-gcs.ipynb` (GCS) | 16/16 |
| `Ch-1/exercises/Exp1.7.2-drake-systems.ipynb` | 70/70 |
| `Ch-1/exercises/Exp1.7.3-physics-simulation.ipynb` | 50/50 |
| `Ch-1/exercises/Exp1.7.4-hardwarestation.ipynb` | 50/50 |

## Notes on individual runs

* Monte-Carlo studies use 100 trials with a fixed seed.
* The LittleDog gait uses SNOPT with the major-iteration limit raised to 100;
  the default limit returns an infeasible point.
* The MIQP uses branch and bound with OSQP at each node; GCS uses
  `max_rounded_paths = 10` with SNOPT for the rounded paths.
* The hopper sensitivity uses an 8 s simulation and the last 2 s for the height
  statistics.
